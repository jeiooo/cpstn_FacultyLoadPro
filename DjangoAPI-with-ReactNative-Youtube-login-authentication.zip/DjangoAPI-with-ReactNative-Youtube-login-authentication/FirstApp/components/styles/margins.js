import React, { useContext } from 'react';
import { StyleSheet, Dimensions } from 'react-native';

export default StyleSheet.create({

  topTenPercent: {
    marginTop: "10%"
  },
  top30Percent: {
    marginTop: "30%"
  },
  allTenPercent: {
    margin: "10%"
  },
  bottomTenPercent: {
    margin: "10%"
  },
  rightTenPercent: {
    margin: "10%"
  },
  leftTenPercent: {
    margin: "10%"
  },





});

//export default margins;
